﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt



.. _internet-explorer-and-html-tag-abbr:

Internet Explorer and HTML tag abbr
-----------------------------------

Before IE7, Internet Explorer did not support HTML tag abbr. If a
content element containing this tag is edited with htmlArea RTE in
IE6, the tag may be broken. Therefore, abbr tags are transformed to
acronym tags if IE6 is used.


