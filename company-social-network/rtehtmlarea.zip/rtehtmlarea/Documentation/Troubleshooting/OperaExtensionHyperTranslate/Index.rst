﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt



.. _opera-extension-hyper-translate:

Issue with Opera extension Hyper Translate
------------------------------------------

.. _opera-extension-hyper-translate-problem:

Problem:
""""""""

When the Opera extension Hyper Translate is installed, hidden markup
is added at the end of the text edted in the RTE.


.. _opera-extension-hyper-translate-solution:

Solution:
"""""""""

Remove extension Hyper Translate.

TSconfig EXT: htmlArea RTE - 58
