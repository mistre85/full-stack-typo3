﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt



.. _front-end-plugins:

Using htmlArea RTE in a front end plugin
----------------------------------------

If you are a TYPO3 front end extension developer, your extensions may
use the htmlArea RTE API to enable rich text editing of text fields.
You will find the the htmlArea RTE API Manual on the TYPO3 Extension
Repository (extension key: rtehtmlarea\_api\_manual)

Note that the TYPO3 Image, TYPO3 Link , User Elements and Acronym
features are not available when the RTE is used in the TYPO3 front
end.


