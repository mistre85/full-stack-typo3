﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt



.. _default-website-language:

Default Website Language
------------------------

If you enable the Spell Checker feature, make sure you have created a
Website Language record for the default language of your site, even if
your TypoScript template does not refer to it.


