﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt



.. _installing-multiple-rtes:

Installing multiple RTE's
-------------------------

You can install as many RTE's has you wish. Their availability will be
checked in the order in which they are loaded, that is in the order
they are installed.


