﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../../Includes.txt



.. _elements-list:

List of inline elements
^^^^^^^^^^^^^^^^^^^^^^^

In addition to the inline elements listed under text formating above,
classes may be assigned to abbr and acronym elements:

abbr, acronym, b, bdo, big, cite, code, del, dfn, em, i, ins, kbd, q,
samp, small, span, strike, strong, sub, sup, tt, u, var

