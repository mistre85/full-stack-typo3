﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../../Includes.txt



.. _drop-down-labels:

Labels in the text styling drop-down list
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

In the selectlist, both, the label and the class selector or class
name may be shown:

label

class name - label

label - class name

Labels are always shown in the author's language regardless of the
content's language.

The order is alphabetical.

