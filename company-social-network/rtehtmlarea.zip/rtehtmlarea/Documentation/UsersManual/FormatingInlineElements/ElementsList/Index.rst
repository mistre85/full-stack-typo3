﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../../Includes.txt



.. _list-of-inline-elements:

List of inline elements
^^^^^^^^^^^^^^^^^^^^^^^

b, bdo, big, cite, code, del, dfn, em, i, ins, kbd, q, samp, small,
span, strike, strong, sub, sup, tt, u, var

