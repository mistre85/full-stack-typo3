﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../../Includes.txt



.. _definition-lists-buttons:

Buttons
^^^^^^^

The following buttons are used:

#. a button allowing to create definition lists (dl);

#. a button allowing to toggle between term (dt) and definition (dd)
   elements;

#. indenting and outdenting of definition lists is done using the
   indent/outdent buttons or the TAB/SHIFT-TAB keys.

In the toolbar, the definition list and definition item buttons are
usually placed right after the unordered list (ul) and the ordered
list (ol) buttons.

